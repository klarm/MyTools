export LANG=en_US.UTF-8

cd $1

#echo "the 1 $1"
git stash
git pull

#sss = "which pod"
#echo "the 2 $sss"
#protoc_path=$(which pod)

 if [ -x "/usr/local/bin/pod" ]; then
    /usr/local/bin/pod cache clean --all
    /usr/local/bin/pod update
else
   echo "Node.js binary not executable!"
   exit 2
fi


